package com.example.fletcherrocket;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FireworksComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.VillagerProfession;

import java.util.List;

public class FletcherRocketMod implements ModInitializer {

    @Override
    public void onInitialize() {
        // Adds a new level 3 fletcher trade: 3 emeralds -> 5 firework rockets (flight duration 3)
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.FLETCHER, 3, factories -> {
            factories.add((entity, random) -> {
                ItemStack rockets = new ItemStack(Items.FIREWORK_ROCKET, 5);
                rockets.set(DataComponentTypes.FIREWORKS, new FireworksComponent(3, List.of()));

                return new TradeOffer(
                        new ItemStack(Items.EMERALD, 3), // cost
                        rockets,                          // sold item
                        12,                                // max uses
                        2,                                 // xp given to villager
                        0.05f                              // price multiplier
                );
            });
        });
    }
}
